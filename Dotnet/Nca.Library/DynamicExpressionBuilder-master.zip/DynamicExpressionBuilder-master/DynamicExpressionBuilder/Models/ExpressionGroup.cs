﻿using DynamicExpressionBuilder.Enums;
using System.Collections.Generic;

namespace DynamicExpressionBuilder.Models
{
    /// <summary>
    /// Expression group
    /// </summary>
    public class ExpressionGroup
    {
        /// <summary>
        /// Conditions
        /// </summary>
        public IList<ExpressionInput> Conditions { get; set; }
        /// <summary>
        /// Expression operand
        /// </summary>
        public Operand Operand { get; set; }
    }
}
