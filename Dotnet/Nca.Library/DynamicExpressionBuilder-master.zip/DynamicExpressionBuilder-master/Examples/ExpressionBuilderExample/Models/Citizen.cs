﻿namespace ExpressionBuilderExample.Models
{
    public class Citizen
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string State { get; set; }

        public bool CrimeRecord { get; set; }

        public long AnnualIncome { get; set; }
    }
}
