﻿using DynamicExpressionBuilder.Enums;
using DynamicExpressionBuilder.Models;
using ExpressionBuilderExample.Helpers;
using ExpressionBuilderExample.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ExpressionBuilderExample
{
    class Program
    {
        static void Main(string[] args)
        {

            var expressionList = ExpressionInputGenerator.GetExpressionInputList();
            var citizenRecords = CitizenRecordGenerator.GetCitizenRecordList();

            //var expression = DynamicExpressionBuilder.ExpressionBuilder.GetExpression<Citizen>(expressionList);\
            var group = new List<ExpressionGroup>() {
                new ExpressionGroup()
                {
                    Conditions = expressionList,
                    Operand = Operand.And
                },
                 new ExpressionGroup()
                {
                    Conditions = ExpressionInputGenerator.GetExpressionInputList2(),
                    Operand = Operand.Or
                }
            };
            var expression = DynamicExpressionBuilder.ExpressionBuilder.GetExpression<Citizen>(group);

            
            Console.WriteLine($"Final Expression = {expression.ToString()}");

            var filterCitizens = citizenRecords.Where(expression.Compile());
            Console.WriteLine($"\nFilter records: {filterCitizens.Count()}");

            Console.ReadLine();
        }
    }
}
