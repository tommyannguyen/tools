﻿using Ips.Repository;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Schema;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Ips.Bot.Factories
{
    public class BotFactory
    {
        public const string NoneOfAbove = "None of the above.";
        private const string AppCustomSource = "Ips_Custom_Source";

        public IMessageActivity CreateSuggestionCard(List<string> suggestionsList, string cardTitle = "Hello , did you mean:", string cardNoMatchText = NoneOfAbove)
        {
            var chatActivity = Activity.CreateMessageActivity();
            var buttonList = new List<CardAction>();

            // Add all suggestions
            foreach (var suggestion in suggestionsList)
            {
                buttonList.Add(
                    new CardAction()
                    {
                        Value = suggestion,
                        Type = "imBack",
                        Title = suggestion,
                    });
            }

            // Add No match text
            buttonList.Add(
                new CardAction()
                {
                    Value = cardNoMatchText,
                    Type = "imBack",
                    Title = cardNoMatchText
                });

            var plCard = new HeroCard()
            {
                Title = cardTitle,
                Subtitle = string.Empty,
                Buttons = buttonList
            };

            // Create the attachment.
            var attachment = plCard.ToAttachment();

            chatActivity.Attachments.Add(attachment);

            return chatActivity;
        }

        public QnaFeedbackRecords CreateQnaFeedbackRecords(QnaFeedbackRecord[] feedbackRecords)
        {
            return new QnaFeedbackRecords()
            {
                FeedbackRecords = feedbackRecords
            };
        }
        public QnaFeedbackRecord CreateQnaFeedbackRecord(
               string userId,
               string userQuestion,
               int qnaId)
        {
            return new QnaFeedbackRecord()
            {
                UserId = userId,
                QnaId = qnaId,
                UserQuestion = userQuestion
            };
        }
        public QnaDocument CreateQnaDocument(int id,
                        List<string> questions,
                        string answer)
        {
            return new QnaDocument()
            {
                Id = id,
                Questions = questions,
                Answer = answer,
                Source = AppCustomSource
            };
        }

        public IMessageActivity CreateAnswerCard(QnaQueryResult qnaQueryResult)
        {
            return qnaQueryResult.IsChitChatContext() ? CreateChitChatCard(qnaQueryResult) : CreateNormalCard(qnaQueryResult);
        }
        private IMessageActivity CreateNormalCard(QnaQueryResult qnaQueryResult)
        {
            var chatActivity = Activity.CreateMessageActivity();
            var buttonList = new List<CardAction>();
            if (qnaQueryResult.Context != null && qnaQueryResult.Context.Prompts.Any())
            {
                buttonList.AddRange(
                    qnaQueryResult.Context.Prompts.OrderBy(o => o.DisplayOrder).Select(prompt =>
                           new CardAction()
                           {
                               Value = prompt.DisplayText,
                               Type = "imBack",
                               Title = prompt.DisplayText,
                           })
                    );
            }
            var plCard = new HeroCard()
            {
                Title = string.Empty,
                Text = qnaQueryResult.Answer,
                Buttons = buttonList,
            };
            chatActivity.Attachments.Add(plCard.ToAttachment());

            return chatActivity;
        }
        
        private IMessageActivity CreateChitChatCard(QnaQueryResult qnaQueryResult)
        {
            var catUrls = new List<string>() {
                "https://visualhunt.com/photos/1/kitten-with-closed-eyes-licking-paw.jpg?s=s",
                "https://visualhunt.com/photos/1/portrait-of-curious-cat.jpg?s=s",
                "https://visualhunt.com/photos/1/black-and-white-kitten-yawning.jpg?s=s",
                "https://visualhunt.com/photos/1/portrait-of-cat-in-snow.jpg?s=s,",
                "https://visualhunt.com/photos/1/cat-animal-cute-pet-feline-kitty.jpg?s=s",
                "https://visualhunt.com/photos/6/cat-cute-cat-cat-face-animal-katze-cats-eyes.jpg?s=s",
                "https://visualhunt.com/photos/5/cat-animal-pet-mieze-adidas-domestic-cat.jpg?s=s",
                "https://visualhunt.com/photos/6/cat-kitten-cat-baby-oriental-shorthair-fur-1.jpg?s=s",
                "https://visualhunt.com/photos/4/cat-animal-sleep-cats-pet-animals-cute-nap.jpg?s=s",
                "https://visualhunt.com/photos/2/cat-white-feline-cute-resting-furniture-indoors.jpg?s=s",
                "https://visualhunt.com/photos/5/kitten-cat-pet-animals-animal-feline-cats.jpg?s=s",
                "https://visualhunt.com/photos/6/cat-cat-face-head-cats-eyes-animals-curious-1.jpg?s=s",
                "https://visualhunt.com/photos/2/cat-hangover-red-cute-mackerel-tiger-sweet-6.jpg?s=s",
                "https://visualhunt.com/photos/7/cat-kitten-animal-feline-yawn-gape.jpg?s=s",
            };
            var random = new Random();
            int index = random.Next(catUrls.Count);

            var chatActivity = Activity.CreateMessageActivity();
            var buttonList = new List<CardAction>();
            var cartImages = new List<CardImage>
            {
                new CardImage()
                {
                    Url = catUrls[index]
                }
            };
            var card = new HeroCard()
            {
                Title = string.Empty,
                Text = qnaQueryResult.Answer,
                Buttons = buttonList,
                Images = cartImages
            };

            chatActivity.Attachments.Add(card.ToAttachment());
            return chatActivity;

        }
    }
}
