﻿using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Ips.Bot.Services;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;

namespace Ips.Bot
{
    public class QnAMainBot : ActivityHandler
    {
        private readonly ILogger<QnAMainBot> _logger;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ActiveBotServices _activeBotServices;
        public QnAMainBot(
            ILogger<QnAMainBot> logger,
            IHttpClientFactory httpClientFactory,
            ActiveBotServices activeBotServices)
        {
            _logger = logger;
            _httpClientFactory = httpClientFactory;
            _activeBotServices = activeBotServices;
        }
        public override async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default)
        {
            await base.OnTurnAsync(turnContext, cancellationToken);
        }
        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in turnContext.Activity.MembersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await SendWelcomeMessageAsync(turnContext, member.Name);
                }
            }
            await base.OnMembersAddedAsync(membersAdded, turnContext, cancellationToken);
        }
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            DialogContext dialogContext = await _activeBotServices.DialogSet.CreateContextAsync(turnContext, cancellationToken);
            DialogTurnResult results = await dialogContext.ContinueDialogAsync(cancellationToken);
            switch (results.Status)
            {
                case DialogTurnStatus.Cancelled:
                case DialogTurnStatus.Empty:
                    await _activeBotServices.BeginDialogAsync(dialogContext);
                    break;
                case DialogTurnStatus.Complete:
                    break;
                case DialogTurnStatus.Waiting:
                    break;
            }

            await _activeBotServices.ConversationState.SaveChangesAsync(turnContext);

        }


        //TODO:: Factory create intance
        private async Task SendWelcomeMessageAsync(ITurnContext turnContext, string userName)
        {
            await turnContext.SendActivityAsync($"Welcome to Ips Q&A Bot");
        }
    }
}
