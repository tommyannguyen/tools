﻿using Ips.Bot.Factories;
using Ips.Library;
using Ips.Repository;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Bot.Builder.Dialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Ips.Bot.Services
{
    public class ActiveBotServices
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly QnaConfiguration _configuration;
        private readonly BotFactory _botFactory;
        private readonly QnaRepository _qnaCustomRepository;

        private const string dialogName = "ips-active-dialog";
        private const string CurrentQuery = "value-current-query";
        private const string QnAData = "value-qnaData";
        private const string QnADebugMode = "value-qnaDebug";
        private const string DebugKey = ":debug";
        private const float DefaultThreshold = 0.03F;
        private const int DefaultTopN = 3;


        private const double MinimumScoreForLowScoreVariation = 20.0;
        private const double PreviousLowScoreVariationMultiplier = 1.4;
        private const double MaxLowScoreVariationMultiplier = 2.0;
        private const double MaximumScoreForLowScoreVariation = 80.0;

        private const int CardOptionsLimitation = 100;
        public ActiveBotServices(
            IHttpClientFactory httpClientFactory,
            QnaConfiguration configuration,
            BotFactory botFactory,
            QnaRepository qnaRepository)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
            _botFactory = botFactory;
            _qnaCustomRepository = qnaRepository;

            InitialBotResources();
        }

        public QnaRepository QnAReaderRepository
        {
            get
            {
                //var httpClient = _httpClientFactory.CreateClient();
                //return new QnAMaker(new QnAMakerEndpoint
                //{
                //    KnowledgeBaseId = _configuration.KnowledgeBaseId,
                //    EndpointKey = _configuration.ResourceKey,
                //    Host = _configuration.Endpoint
                //},
                //null,
                //httpClient);

                return _qnaCustomRepository;
            }
        }
        public QnaRepository QnAWriterRepository
        {
            get
            {
                return _qnaCustomRepository;
            }
        }

        public string ActiveLearningDialogName => dialogName;
        public DialogSet DialogSet { get; private set; }
        public ConversationState ConversationState { get; private set; }

        public async Task BeginDialogAsync(DialogContext dialogContext)
        {
            await dialogContext.BeginDialogAsync(dialogName, new QnAMakerOptions
            {
                Top = DefaultTopN,
                ScoreThreshold = DefaultThreshold,
            });
        }
        private void InitialBotResources()
        {
            if (DialogSet != null) return;

            ConversationState = new ConversationState(new MemoryStorage());
            var statePropertyAccessor = ConversationState.CreateProperty<DialogState>("DialogState");

            DialogSet = new DialogSet(statePropertyAccessor);
            var appDialog = new WaterfallDialog(dialogName)
               .AddStep(CallGenerateAnswer)
               .AddStep(FilterLowVariationScoreList)
               .AddStep(CallTrain)
               .AddStep(DisplayQnAResult);
            DialogSet.Add(appDialog);
        }
        private async Task<DialogTurnResult> CallGenerateAnswer(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var scoreThreshold = DefaultThreshold;
            var top = DefaultTopN;

            FormatContext(stepContext);
            QnAMakerOptions qnaMakerOptions = null;

            // Getting options
            if (stepContext.ActiveDialog.State["options"] != null)
            {
                qnaMakerOptions = stepContext.ActiveDialog.State["options"] as QnAMakerOptions;
                scoreThreshold = qnaMakerOptions?.ScoreThreshold != null ? qnaMakerOptions.ScoreThreshold : DefaultThreshold;
                top = qnaMakerOptions?.Top != null ? qnaMakerOptions.Top : DefaultTopN;
            }


            var question = stepContext.Context.Activity.Text;
            var response = await QnAReaderRepository.GetAnswersAsync(question, qnaMakerOptions);

            var filteredResponse = response.Where(answer => answer.Score > scoreThreshold).ToList();

            stepContext.Values[QnAData] = new List<QnaQueryResult>(filteredResponse);
            stepContext.Values[CurrentQuery] = question;
            return await stepContext.NextAsync(cancellationToken);
        }
        private bool IsChitChatResult(List<QnaQueryResult> qnaQueryResults)
        {
            return qnaQueryResults.Count > 0 && qnaQueryResults.FirstOrDefault().IsChitChatContext();
        }

        private async Task<DialogTurnResult> FilterLowVariationScoreList(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var qnaQueryResults = stepContext.Values[QnAData] as List<QnaQueryResult>;

            if(IsChitChatResult(qnaQueryResults))
            {
                return await stepContext.NextAsync(new List<QnaQueryResult>(qnaQueryResults), cancellationToken);
            }

            qnaQueryResults.RemoveAll(r => r.IsChitChatContext());
            var filteredResponse = GetLowScoreVariation(qnaQueryResults);
            stepContext.Values[QnAData] = filteredResponse;
            if (filteredResponse.Count == 0)
            {
                return await stepContext.NextAsync(new List<QnaQueryResult>(qnaQueryResults), cancellationToken);
            }

         
            var suggestedQuestions = filteredResponse.SelectMany(s => s.Questions).Take(CardOptionsLimitation).ToList();
           
            var message = _botFactory.CreateSuggestionCard(suggestedQuestions);
            await stepContext.Context.SendActivityAsync(message);
            await DebugModeAsync(stepContext);

            return new DialogTurnResult(DialogTurnStatus.Waiting);
        }

        private async Task<DialogTurnResult> CallTrain(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var qnaQueryResults = stepContext.Values[QnAData] as List<QnaQueryResult>;
            var currentQuery = stepContext.Values[CurrentQuery] as string;

            if (IsChitChatResult(qnaQueryResults))
            {
                return await stepContext.NextAsync(new List<QnaQueryResult>(qnaQueryResults), cancellationToken);
            }

            if (qnaQueryResults.Count > 1)
            {
                var reply = stepContext.Context.Activity.Text;
                var qnaResult = qnaQueryResults.Where(kvp => kvp.Questions.Any(q => q.Equals(reply))).FirstOrDefault();

                if (reply.Equals(BotFactory.NoneOfAbove))
                {
                    await SendGoodByeMessageAsync(stepContext);
                    return await stepContext.EndDialogAsync();
                }

                if (qnaResult != null)
                {
                    stepContext.Values[QnAData] = new List<QnaQueryResult>() { qnaResult };


                    //Note: Training data
                    var records = new QnaFeedbackRecord[]
                    {
                         _botFactory.CreateQnaFeedbackRecord(stepContext.Context.Activity.Id, currentQuery, qnaResult.Id)
                    };
                    var feedbackRecords = _botFactory.CreateQnaFeedbackRecords(records);

                    await _qnaCustomRepository.TrainAsync(feedbackRecords, cancellationToken);

                    // Note : Custom data
                    //var document = _botFactory.CreateQnaDocument(0, new List<string> { currentQuery }, qnaResult.Answer);
                    //await _qnaWriterRepository.AddAsync(document);

                    return await stepContext.NextAsync(new List<QnaQueryResult>() { qnaResult }, cancellationToken);
                }
                return await stepContext.EndDialogAsync();
            }

            return await stepContext.NextAsync(stepContext.Result, cancellationToken);
        }

        private async Task<DialogTurnResult> DisplayQnAResult(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            if (stepContext.Result is List<QnaQueryResult> response && response.Count > 0)
            {
                await stepContext.Context.SendActivityAsync(_botFactory.CreateAnswerCard(response[0]), cancellationToken: cancellationToken);
                await DebugModeAsync(stepContext);
            }
            else
            {
                var msg = "No answers found. Please try to ask me another question.";
                await stepContext.Context.SendActivityAsync(msg, cancellationToken: cancellationToken);
            }

            return await stepContext.EndDialogAsync();
        }

        /*
         Logic : Find the result having score from 20-80% if the first record score is from that
             */
        private List<QnaQueryResult> GetLowScoreVariation(List<QnaQueryResult> qnaSearchResults)
        {
            var filteredQnaSearchResult = new List<QnaQueryResult>();

            if (qnaSearchResults == null || qnaSearchResults.Count == 0)
            {
                return filteredQnaSearchResult;
            }

            if (qnaSearchResults.Count == 1)
            {
                return qnaSearchResults;
            }

            var topAnswerScore = qnaSearchResults[0].Score * 100;
            var prevScore = topAnswerScore;

            if ((topAnswerScore > MinimumScoreForLowScoreVariation) && (topAnswerScore <= MaximumScoreForLowScoreVariation))
            {
                filteredQnaSearchResult.Add(qnaSearchResults[0]);

                for (var i = 1; i < qnaSearchResults.Count; i++)
                {
                    var currentScore = qnaSearchResults[i].Score * 100;
                    if (IncludeForClustering(prevScore, currentScore, PreviousLowScoreVariationMultiplier)
                        && IncludeForClustering(topAnswerScore, currentScore, MaxLowScoreVariationMultiplier))
                    {
                        prevScore = qnaSearchResults[i].Score * 100;
                        filteredQnaSearchResult.Add(qnaSearchResults[i]);
                    }
                }
            }

            return filteredQnaSearchResult;
        }
        private bool IncludeForClustering(double prevScore, double currentScore, double multiplier)
        {
            return (prevScore - currentScore) < (multiplier * Math.Sqrt(prevScore));
        }
        private void FormatContext(WaterfallStepContext stepContext)
        {
            var reply = stepContext.Context.Activity.Text;
            reply = !string.IsNullOrEmpty(reply) ? reply : string.Empty;
            if(reply.Contains(DebugKey))
            {
                var formatedReply = reply.Replace(DebugKey, string.Empty);
                stepContext.Context.Activity.Text = formatedReply;
                stepContext.Values[QnADebugMode] = formatedReply;
            }
            else
            {
                stepContext.Values[QnADebugMode] = string.Empty;
            }
            
        }
        private async Task DebugModeAsync(WaterfallStepContext stepContext)
        {
            var qnaQueryResults = stepContext.Values[QnAData] as List<QnaQueryResult>;
            if(qnaQueryResults == null || qnaQueryResults.Count == 0)
            {
                return;
            }

            if (stepContext.Values.TryGetValue(QnADebugMode, out object currentQuery))
            {
                var text = currentQuery.ToString();
                if (!string.IsNullOrEmpty(text))
                {
                    await stepContext.Context.SendActivityAsync($"DEBUG: {JsonHelper.ToString(qnaQueryResults)}");
                }
            }
        }
        private async Task SendGoodByeMessageAsync(WaterfallStepContext stepContext)
        {
            await stepContext.Context.SendActivityAsync($"I'm sorry, I'm still not smart enough. Please try to ask me another question.");
        }
    }
}
