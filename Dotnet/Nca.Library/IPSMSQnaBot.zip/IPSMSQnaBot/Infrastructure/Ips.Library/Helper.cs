﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace Ips.Library
{
    public class JsonHelper
    {
        private static JsonSerializerSettings JsonSerializerSettings
        {
            get
            {
                var serializerSettings = new JsonSerializerSettings();
                serializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                return serializerSettings;
            }
        }
        public static string ToString(object data)
        {
            return JsonConvert.SerializeObject(data, JsonSerializerSettings);
        }
        public static T ToDomainModel<T>(string json)
        {
             return JsonConvert.DeserializeObject<T>(json, JsonSerializerSettings);
        }
      
    }
}
