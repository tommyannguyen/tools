﻿using System.Net.Http.Headers;

namespace Ips.Repository
{
    public struct QnaResponse
    {
        public HttpResponseHeaders headers;
        public string response;

        public QnaResponse(HttpResponseHeaders headers, string response)
        {
            this.headers = headers;
            this.response = response;
        }
    }
}
