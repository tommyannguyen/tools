﻿using Ips.Library;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.AI.QnA;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ips.Repository
{
    public class QnaRepository
    {
        private readonly ILogger _logger;
        private readonly QnaConfiguration _qnaConfiguration;
        static SemaphoreSlim semaphoreSlim = new SemaphoreSlim(1, 1);
        public QnaRepository(
            QnaConfiguration qnaConfiguration,
            ILoggerFactory loggerFactory
           )
        {
            _logger = loggerFactory.CreateLogger<QnaRepository>();
            _qnaConfiguration = qnaConfiguration;
        }

        public async Task Publish()
        {
            using (var client = new HttpClient())
            using (var request = GetDefaultHttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri($"{_qnaConfiguration.SubscriptionEndPoint}/knowledgebases/{_qnaConfiguration.KnowledgeBaseId}");
                var response = await client.SendAsync(request);
            }
        }

        public async Task CreateAsync(QnaKb qnaKb)
        {
            await semaphoreSlim.WaitAsync();

            try
            {
                string uri = $"{_qnaConfiguration.SubscriptionEndPoint}/knowledgebases/create";

                var response = await Post(uri, JsonHelper.ToString(qnaKb));
                var operation = response.headers.GetValues("Location").First();
                var done = false;
                while (true != done)
                {
                    response = await GetStatus(operation);
                    var fields = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.response);

                    var state = fields["operationState"];
                    if (state.CompareTo("Running") == 0 || state.CompareTo("NotStarted") == 0)
                    {
                        var wait = response.headers.GetValues("Retry-After").First();
                        Thread.Sleep(int.Parse(wait) * 1000);
                    }
                    else
                    {
                        done = true;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Q&A", ex);
            }
            finally
            {
                semaphoreSlim.Release();
            }
        }

        public async Task<IEnumerable<QnaDocument>> GetAsync()
        {
            using (var client = new HttpClient())
            using (var request = GetDefaultHttpRequestMessage())
            {
                request.Method = HttpMethod.Get;
                request.RequestUri = new Uri($"{_qnaConfiguration.SubscriptionEndPoint}/knowledgebases/{_qnaConfiguration.KnowledgeBaseId}/prod/qna/");
                var response = await client.SendAsync(request);
                var strData = await response.Content.ReadAsStringAsync();
                return JsonHelper.ToDomainModel<QnaDocumentResult>(strData).QnaDocuments;
            }
        }

        public async Task UpdateKbAsync(string kb, QnaModify model)
        {
            await semaphoreSlim.WaitAsync();

            try
            {
                var response = await PostUpdateKB(kb, JsonHelper.ToString(model));
                var operation = response.headers.GetValues("Location").First();
                var done = false;
                while (true != done)
                {
                    response = await GetStatus(operation);
                    var fields = JsonConvert.DeserializeObject<Dictionary<string, string>>(response.response);

                    var state = fields["operationState"];
                    if (state.CompareTo("Running") == 0 || state.CompareTo("NotStarted") == 0)
                    {
                        var wait = response.headers.GetValues("Retry-After").First();
                        Thread.Sleep(int.Parse(wait) * 1000);
                        
                    }
                    else
                    {
                        done = true;
                    }
                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Q&A", ex);
            }
            finally
            {
                semaphoreSlim.Release();
            }
        }

        public async Task AddAsync(QnaDocument qnaDocument)
        {
            var model = new QnaModify()
            {
                Add = new QnaModifyAdd()
                {
                    QnaList = new List<QnaDocument>() {
                        qnaDocument
                    }
                },

                Delete = new QnaModifyDelete(),
                Update = new QnaModifyUpdate(),
            };

            await UpdateKbAsync(_qnaConfiguration.KnowledgeBaseId, model);

            await Publish();
        }
        public async Task TrainAsync(QnaFeedbackRecords feedbackRecords, CancellationToken cancellationToken)
        {
            await semaphoreSlim.WaitAsync();

            try
            {
                string uri = $"{_qnaConfiguration.Endpoint}/knowledgebases/{_qnaConfiguration.KnowledgeBaseId}/train/";
                await Post(uri, JsonHelper.ToString(feedbackRecords));
            }
            catch (Exception ex)
            {
                _logger.LogError("Q&A", ex);
            }
            finally
            {
                semaphoreSlim.Release();
            }
            
        }
        public async Task<IEnumerable<QnaQueryResult>> GetAnswersAsync(string questionQuery, QnAMakerOptions options)
        {
            var response = await QueryQnaServiceAsync(questionQuery, options);

            return JsonConvert.DeserializeObject<QnaAnswer>(response.response).Answers;
        }
        //===============================================PRIVATE FUNCTIONS====================================
        private async Task<QnaResponse> QueryQnaServiceAsync(string questionQuery, QnAMakerOptions options)
        {
            var requestUrl = $"{_qnaConfiguration.Endpoint}/knowledgebases/{_qnaConfiguration.KnowledgeBaseId}/generateanswer";
            
            using (var client = new HttpClient())
            using (var request = GetDefaultHttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(requestUrl);
                request.Content = new StringContent(JsonHelper.ToString(new
                {
                    question = questionQuery,
                    top = options.Top,
                    strictFilters = options.StrictFilters,
                    metadataBoost = options.MetadataBoost,
                    scoreThreshold = options.ScoreThreshold,
                }), Encoding.UTF8, "application/json");

                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                return new QnaResponse(response.Headers, responseBody);
            }
        }
        private async Task<QnaResponse> Post(string uri, string body)
        {
            using (var client = new HttpClient())
            using (var request = GetDefaultHttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(uri);
                request.Content = new StringContent(body, Encoding.UTF8, "application/json");
              
                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                return new QnaResponse(response.Headers, responseBody);
            }
        }
        private async Task<QnaResponse> Patch(string uri, string body)
        {
            using (var client = new HttpClient())
            using (var request = GetDefaultHttpRequestMessage())
            {
                request.Method = new HttpMethod("PATCH");
                request.RequestUri = new Uri(uri);
                request.Content = new StringContent(body, Encoding.UTF8, "application/json");

                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                return new QnaResponse(response.Headers, responseBody);
            }
        }

        private HttpRequestMessage GetDefaultHttpRequestMessage()
        {
            var request = new HttpRequestMessage();
            request.Headers.Add("Ocp-Apim-Subscription-Key", _qnaConfiguration.SubscriptionKey);
            request.Headers.Add("Authorization", "EndpointKey " + _qnaConfiguration.ResourceKey);
            return request;
        }
        private async Task<QnaResponse> PostUpdateKB(string kb, string newKb)
        {
            string uri = $"{_qnaConfiguration.SubscriptionEndPoint}/knowledgebases/{kb}";
            return await Patch(uri, newKb);
        }
        private async Task<QnaResponse> Get(string uri)
        {
            using (var client = new HttpClient())
            using (var request = GetDefaultHttpRequestMessage())
            {
                request.Method = HttpMethod.Get;
                request.RequestUri = new Uri(uri);
                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                return new QnaResponse(response.Headers, responseBody);
            }
        }

        private async Task<QnaResponse> GetStatus(string operation)
        {
            string uri = $"{_qnaConfiguration.SubscriptionEndPoint}/{operation}";
            return await Get(uri);
        }

    }
}
