﻿using System.Collections.Generic;

namespace Ips.Repository
{
    public class QnaDocumentResult
    {
        public IEnumerable<QnaDocument> QnaDocuments { get; set; }
    }
    public class QnaDocument
    {
        public int Id { get; set; } = 0;
        public string Answer { get; set; }
        public string Source { get; set; }
        public IEnumerable<string> Questions { get; set; }
        public IEnumerable<QueryResultMetadata> Metadata { get; set; }
        public string AlternateQuestions { get; set; }
        public QnaContext Context { get; set; }
    }
    public class QnaContext
    {
        public bool IsContextOnly { get; set; }
        public IEnumerable<string> Prompts { get; set; }
    }
    public class QueryResultMetadata
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
    public class QnaKb
    {
        public string Name { get; set; }
        public IEnumerable<QnaDocument> QnaList { get; set; } = new List<QnaDocument>();
        public IEnumerable<string> Urls { get; set; } = new List<string>();
        public IEnumerable<string> Files { get; set; } = new List<string>();
    }
    public class QnaModify
    {
        public QnaModifyAdd Add { get; set; }
        public QnaModifyDelete Delete { get; set; }
        public QnaModifyUpdate Update { get; set; }
    }
    public class QnaModifyAdd
    {
        public IEnumerable<QnaDocument> QnaList { get; set; }
        public IEnumerable<string> Urls { get; set; }
        public IEnumerable<string> Files { get; set; }
    }
    public class QnaModifyDelete
    {
        public IEnumerable<int> Ids { get; set; }
    }
    public class QnaModifyUpdate
    {
        public string Name { get; set; }
        public IEnumerable<string> Urls { get; set; }
        public IEnumerable<QnaUpdateDocument> QnaList { get; set; }
    }
    public class QnaUpdateDocument
    {
        public int Id { get; set; }
        public string Answer { get; set; }
        public string Source { get; set; }
        public IEnumerable<QnaUpdateData> Questions { get; set; }
        public IEnumerable<QnaUpdateData> Metadata { get; set; }
    }
    public class QnaUpdateData
    {
        public IEnumerable<string> Add { get; set; }
        public IEnumerable<string> Delete { get; set; }
    }
    public class QnaFeedbackRecords
    {
        public QnaFeedbackRecord[] FeedbackRecords { get; set; }
    }
    public class QnaFeedbackRecord
    {
        public string UserId { get; set; }
        public string UserQuestion { get; set; }
        public int QnaId { get; set; }
    }



    public class Prompt
    {
        public int DisplayOrder { get; set; }
        public int QnaId { get; set; }
        public dynamic QnA { get; set; }
    }
    public class QnaResultContext
    {
        public bool IsContextOnly { get; set; }
        public IEnumerable<QnaResultPrompt> Prompts { get; set; }
    }
    public class QnaResultMetadata
    {
        public string Name { get; set; }

        public string Value { get; set; }
    }
    public class QnaResultPrompt
    {
        public int DisplayOrder { get; set; }

        public int QnaId { get; set; }

        public string DisplayText { get; set; }
    }
    public class QnaQueryResult
    { 
        private float score = 0;
        public IEnumerable<string> Questions { get; set; }
        public string Answer { get; set; }
        public float Score
        {
            get => score;
            set
            {
                score = value / 100;
            }
        }
        public IEnumerable<QnaResultMetadata> Metadata { get; set; }
        public string Source { get; set; }
        public int Id { get; set; }
        public QnaResultContext Context { get; set; }

    }
    public class QnaAnswer
    {
        public IEnumerable<QnaQueryResult> Answers { get; set; }
    }

    public static class QnaHelper
    {
        public const string IpsChitchatFriendly = "Ips_chitchat_friendly.tsv";
        public static bool IsChitChatContext(this QnaQueryResult queryResult)
        {
            return !string.IsNullOrEmpty(queryResult.Source) && queryResult.Source.Equals(IpsChitchatFriendly);
        }
    }
}
