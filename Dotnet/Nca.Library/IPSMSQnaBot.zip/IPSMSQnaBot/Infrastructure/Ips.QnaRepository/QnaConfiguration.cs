﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ips.Repository
{
    public class QnaConfiguration
    {
        public string Endpoint { get; set; }
        public string KnowledgeBaseId { get; set; }
        public string ResourceKey { get; set; }
        public string SubscriptionKey { get; set; }
        public string SubscriptionEndPoint { get; set; }
    }
}
