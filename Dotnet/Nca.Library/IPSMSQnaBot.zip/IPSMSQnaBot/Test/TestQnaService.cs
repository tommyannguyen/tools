using Ips.Repository;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace Test
{
    public class TestQnaService
    {
        private readonly QnaRepository _qnaRepository;
        private string _KbId = "6dfc6862-9e69-4b1e-b0bc-1f28e0d38dc9";
        private string _appSource = "Ips_Custom_Source";

        [Obsolete]
        public TestQnaService()
        {
            var cognitiveKey = "e060e56d8a81466fbba385ef68023703";
            var cognitiveEndpoint = "https://westus.api.cognitive.microsoft.com/qnamaker/v4.0";

            ILoggerFactory loggerFactory = new LoggerFactory()
                                        .AddConsole()
                                        .AddDebug();

            var configuration = new QnaConfiguration() {
                SubscriptionEndPoint = cognitiveEndpoint,
                KnowledgeBaseId = _KbId,
                SubscriptionKey = cognitiveKey,

            };
            _qnaRepository = new QnaRepository(
                configuration,
                loggerFactory);
        }

        [Fact]
        public async Task TestGetData()
        {

            var data = await _qnaRepository.GetAsync();


            Assert.True(data.Any());
        }

        [Fact]
        public async Task CreateResource()
        {
            var newKb = new QnaKb()
            {
                Name = "APP_TEST",
                Files = new List<string>(),
                QnaList = new List<QnaDocument>()
                {
                    new QnaDocument()
                    {
                        Id = 1,
                        Answer = "ten ten ten",
                        Questions = new List<string>()
                        {
                            "first question"
                        },
                    }
                },
                Urls = new List<string>()
            };

            await _qnaRepository.CreateAsync(newKb);

            Assert.True(true);
        }

        [Fact]
        public async Task UpdateResource()
        {
            var model = new QnaModify()
            {
                Add = new QnaModifyAdd()
                {
                    QnaList = new List<QnaDocument>() {
                        new QnaDocument()
                        {
                            Questions = new List<string>()
                            {
                                "How are you h�m nay"
                            },
                            Answer = "Con chim non",
                            Source = _appSource
                        }
                    }
                },

                Delete = new QnaModifyDelete()
                {

                },
                Update = new QnaModifyUpdate() {
                  
                },
            };

            await _qnaRepository.UpdateKbAsync(_KbId, model);

            await _qnaRepository.Publish();
            Assert.True(true);
        }
        [Fact]
        public async Task UpdateItemResource()
        {
            var model = new QnaModify()
            {
                Add = new QnaModifyAdd()
                {
                },

                Delete = new QnaModifyDelete()
                {

                },
                Update = new QnaModifyUpdate()
                {
                    Name = "Ips_Custom_Source",
                    Urls = new List<string>(),
                    QnaList = new List<QnaUpdateDocument>()
                    {
                        new QnaUpdateDocument()
                        {
                            Id = 213,
                            Source = "ActiveLearningSampleFAQ.tsv",
                            Answer = "con c� b� b�",
                            Questions = new List<QnaUpdateData>
                            {
                                new QnaUpdateData()
                                {
                                    Add = new List<string>(){ "custom question ?"}
                                }
                            }
                        }
                    }
                },
            };

            await _qnaRepository.UpdateKbAsync(_KbId, model);

            await _qnaRepository.Publish();

            Assert.True(true);
        }
    }
}
