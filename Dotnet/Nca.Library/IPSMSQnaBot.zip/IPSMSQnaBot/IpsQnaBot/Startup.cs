﻿using Ips.Bot.Factories;
using Ips.Bot.Services;
using Ips.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.BotFramework;
using Microsoft.Bot.Builder.Integration.AspNet.Core;
using Microsoft.Bot.Connector.Authentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Ips.Bot
{
    public class Startup
    {
        private readonly IConfiguration _configuration;

        public Startup(IConfiguration config)
        {
            _configuration = config;
        }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddHttpClient();
            services.AddSingleton<ICredentialProvider, ConfigurationCredentialProvider>();
            services.AddSingleton<IBotFrameworkHttpAdapter, AdapterWithErrorHandler>();
            services.AddTransient<IBot, QnAMainBot>();
            services.AddSingleton<QnaConfiguration>( (_) => new QnaConfiguration() {
                KnowledgeBaseId = _configuration["QnAKnowledgebaseId"],
                ResourceKey = _configuration["QnAEndpointKey"],
                Endpoint = _configuration["QnAEndpointHostName"],
                SubscriptionKey = _configuration["QnASubscriptionKey"],
                SubscriptionEndPoint = _configuration["QnASubscriptionEndPoint"],
            });
            services.AddSingleton<QnaRepository>();
            services.AddSingleton<ActiveBotServices>();
            services.AddSingleton<BotFactory>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseMvc();
        }
    }
}
